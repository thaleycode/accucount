import { useState } from "react";
import { Link } from "react-router-dom";
import LoginForm from "../../components/LoginForm/LoginForm";
import SignUpForm from "../../components/SignUpForm/SignUpForm";
import "./AuthPage.css";

export default function AuthPage({ setUser }) {
  const [showSignUpForm, setShowSignUpForm] = useState(false);

  return (
    <div className="AuthPage">
      <h1 className="ledgerly">Accucount</h1>
      <h3>{showSignUpForm ? "Welcome to Accucount" : "Welcome back!"}</h3>
      {showSignUpForm ? (
        <SignUpForm setUser={setUser} />
      ) : (
        <LoginForm setUser={setUser} />
      )}
      <Link onClick={() => setShowSignUpForm(!showSignUpForm)}>
        {showSignUpForm
          ? "Already a user? Log in here."
          : "New to Accucount? Sign up here."}
      </Link>
    </div>
  );
}
