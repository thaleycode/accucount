# Accucount Node.js Application

Accucount is a Node.js application designed for Accounting Automation.

## Getting Started

Follow these instructions to set up and run the Accucount application on your local machine.

### Prerequisites

- [Node.js](https://nodejs.org/) installed on your system

### Installation

1. **Clone the repository:**

   ```bash
   git clone <repository-url>
   cd Accucount
   ```

2. **Install Dependencies:**

   ```bash
   npm install
   ```
3. **Build:**

   ```bash
   npm run build
   ```

### Starting the Application

To start the Accucount application, use the following commands:

- To start the server:

  ```bash
  node server.js
  ```

- To start the application using npm:

  ```bash
  npm start
  ```

### Generating JWT Token

The application uses JSON Web Tokens (JWT) for authentication. You can generate a JWT token using `new.js` and paste it into the `.env` file.

1. **Generate JWT Token:**

   ```bash
   node new.js
   ```

2. **Copy the generated token.**

3. **Update .env file:**

   ```env
   SECRET=<paste-your-generated-token-here>
   ```

### Environment Variables

Make sure to set the following environment variables in your `.env` file:

- `SECRET`: Secret key for generating JWT tokens. Generate and paste the token using `new.js`.